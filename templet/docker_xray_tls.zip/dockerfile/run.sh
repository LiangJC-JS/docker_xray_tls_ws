#!/bin/bash

/usr/sbin/nginx -c /etc/nginx/nginx.conf
/usr/bin/xray run -confdir /etc/xray  
